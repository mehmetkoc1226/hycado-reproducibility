# HyCADO v1 ve YOLO-1280 — VAL boyut ve yoğunluk karşılaştırması

1. ZIP'i **Tümünü ayıkla** ile bir klasöre çıkarın. Proje klasörüne kopyalamanız gerekmez.
2. Ayıklanan klasördeki **16_VAL_BOYUT_YOGUNLUK.cmd** dosyasını çalıştırın. Varsayılan proje yolu `D:\HyCADO_Temiz_Baslangic`. Yol farklıysa CMD'ye ilk argüman olarak tam proje yolunu verebilirsiniz.
3. Aynı klasörde oluşan **16_val_boyut_yogunluk_rapor.zip** dosyasını gönderin. Kaynaklar eksikse aynı ZIP bir hata özeti içerir. Proje Python'u bulunamazsa yalnız ekrandaki hata yeterlidir.

Kod, Windows'taki mevcut HyCADO v1 ve YOLO-1280 VAL tahminlerini ve anotasyonları yerinde okur. Ağırlık, görüntü veya veri kopyalamaz. Eğitim, model çıkarımı, paket kurulumu ve internet erişimi yoktur. Kaynaklar eksik ya da doğrulama başarısızsa durur; alternatif veri kullanmaz.

## Sonucun sınırları

- Karşılaştırma daha önce incelenmiş 548 VisDrone VAL görüntüsü ve aynı dondurulmuş ağırlıklarla yapılır.
- Tüm görüntüde sınıf duyarlı eşleştirme yapılır (IoU 0,50 ve 0,75, ignore işleminden sonra görüntü başına en çok 500 tahmin). Sonra normal GT kutuları özgün kutu alanına göre gruplara ayrılır. Bu, boyuta göre **recall** analizidir; **AP-small** değildir.
- Yoğunluk burada **görüntü başına normal GT nesne sayısı** anlamındadır (0, 1–30, 31–100, 101+). Bu gruplarda recall, FP sayıları ve precision raporlanır. Boyut gruplarına FP atanmaz.
- Eşli recall farkları için önceki analizdeki 75 dosya adı/hash grubuyla 2.000 bootstrap tekrarı yapılır. Aralıklar keşifseldir, çoklu karşılaştırma düzeltmesi yoktur ve yeni eğitimlerin varyansını ölçmez.
- Her model için genel TP, FP ve ignore toplamları önceki resmî VAL kayıtlarıyla birebir eşleşmelidir. Hata raporu dışında hiçbir çıktı projenin eski dosyalarını değiştirmez.
