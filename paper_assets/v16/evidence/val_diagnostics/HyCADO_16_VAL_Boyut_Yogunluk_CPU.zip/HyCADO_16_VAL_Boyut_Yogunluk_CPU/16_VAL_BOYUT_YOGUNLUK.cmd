@echo off
setlocal
set "ROOT=D:\HyCADO_Temiz_Baslangic"
if not "%~1"=="" set "ROOT=%~1"
set "PY=%ROOT%\.venv\Scripts\python.exe"
if not exist "%PY%" (
 echo Proje Python bulunamadi: "%PY%"
 pause
 exit /b 1
)
echo CPU analizi. GPU, egitim, kurulum veya indirme yok.
"%PY%" -B -u "%~dp0analyze.py" --project "%ROOT%"
set "RC=%ERRORLEVEL%"
pause
exit /b %RC%
