"""Unmodified detailed_matches from the HyCADO CPU diagnostics."""
import numpy as np
from dev_metrics import overlaps, match_flags

def detailed_matches(det, gt, threshold):
    """Return flags plus original GT row identities; cross-check old 11 matcher."""
    flags = np.zeros(len(det), dtype=np.int8)
    matched_ids = np.full(len(det), -1, dtype=np.int64)
    for cls in range(1,11):
        did = np.flatnonzero(det[:,5] == cls)
        gid = np.flatnonzero(gt[:,5] == cls)
        gid = gid[np.argsort(gt[gid,4], kind='stable')]
        state = -gt[gid,4].astype(np.int8)
        matrix = overlaps(det[did,:5],gt[gid,:5])
        for j, d in enumerate(did):
            available = np.flatnonzero((state == 0) & (matrix[j] >= threshold))
            if len(available):
                best_overlap = matrix[j,available].max()
                best = available[matrix[j,available] == best_overlap][-1]
                flags[d] = 1; matched_ids[d] = gid[best]; state[best] = 1
            elif np.any((state == -1) & (matrix[j] >= threshold)):
                flags[d] = -1
        expected = match_flags(det[did,:5],gt[gt[:,5] == cls,:5],threshold)
        if not np.array_equal(flags[did],expected):
            raise ValueError('Ayrintili eslesme, 11 eslesmesiyle tutarsiz')
    return flags, matched_ids
