"""Paired CPU diagnostics of two frozen VisDrone VAL outputs, with no model imports."""
import argparse
from collections import Counter
import csv
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import traceback
import zipfile

HERE = Path(__file__).resolve().parent
DEFAULT = Path(r'D:\HyCADO_Temiz_Baslangic')
REPORT = '16_val_boyut_yogunluk_rapor.zip'
P2 = 'p2_strong_baselines_v1_seed42'
HY = 'official_val_a025_v1_seed42'
SHAS = {
 'groups.json':'edb4e2ab80888efcb3ae607286473390013acaf279e19eed6e9035df587054a4',
 'official_val_prediction_index.json':'bf041e21109092a7c4a31b1e1504e00e904ced34119bb2f2ce731fcb7c43052a',
 'official_val_protocol.json':'3149009864dffa172a5db5bbca1bb3fae7aabe8a4a3373a2a42a2ce2525ff217',
 'official_val_metrics.json':'3ceac720677498235408b3000e207d5a8d6bbd7814a1000f844ad01522031137',
 'original_metrics.json':'331ca863f925dcb3145b1c32ec0d27ed243f58dabdad2c194cfe0e6b94d3876a',
 'original_prediction_index.json':'7448cb758b2afbad87c3601221edd77a890be36e336460c66004b21c51abff17',
 'original_protocol.json':'bf406f50d8441fc66346be30615ebdb94b009625e5946e5fa59dd1e5427e686f',
}
AREAS = ('nonpositive','<256','[256,1024)','[1024,9216)','>=9216')
DENSITY = ('0','1-30','31-100','101+')
IOU = (.5,.75)
DRAW_SEED, DRAWS = 20261110, 2000


def need(ok, error):
    if not ok:
        raise ValueError(error)


def sha(b):
    return hashlib.sha256(b).hexdigest()


def fp(doc):
    return sha(json.dumps(doc,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode())


def checked_bytes(path, expected):
    data = path.read_bytes()
    need(sha(data)==expected, f'Dosya kimligi farkli: {path}')
    return data


def safe(base, rel):
    p = PurePosixPath(rel)
    need(not p.is_absolute() and p.parts and '..' not in p.parts and '\\' not in rel and ':' not in rel,
         f'Gecersiz arsiv yolu: {rel}')
    q = base.joinpath(*p.parts).resolve()
    need(q.is_relative_to(base.resolve()), f'Arsiv yolu klasor disinda: {rel}')
    return q


def assert_payload(p, rec, proto):
    need(p.get('content_sha256')==fp({k:v for k,v in p.items() if k!='content_sha256'}) and
         p.get('source_image')==rec['image'] and p.get('image_sha256')==rec['image_sha256'] and
         p.get('protocol_sha256')==proto and (p.get('width'),p.get('height'))==(rec['width'],rec['height']),
         f'Tahmin kaydi uyusmuyor: {rec["image"]}')


def preflight(root, evidence):
    old=evidence['original_protocol.json']; pp=evidence['official_val_protocol.json']
    oi=evidence['original_prediction_index.json']; pi=evidence['official_val_prediction_index.json']
    records=old['records']; og=evidence['groups.json']; s_old=fp(old); s_p2=fp(pp)
    yolo=pi['methods']['yolo1280']; hybrid=oi['records']
    y={x['source_image']:x for x in yolo}; h={x['source_image']:x for x in hybrid}
    need(len(records)==len(h)==len(y)==len(yolo)==len(hybrid)==len(og['image_to_group'])==548 and
         {x['image'] for x in records}==set(h)==set(y) and og['groups_after_hash_union']==75 and
         set(og['image_to_group'])==set(range(75)) and
         old['prepared_manifest_sha256']==pp['official_manifest_sha256'] and
         s_old==pp['previous_baseline_protocol_sha256']==oi['protocol_sha256'] and
         s_p2==pi['protocol_sha256'] and pp['images']==548 and not pp['training'] and not pp['parameter_search'],
         'Dondurulmus 548 VAL kaydi veya grup kimligi farkli')
    paths=[]
    for r,g in zip(records,og['image_to_group']):
        name=r['image']; a,b=h[name],y[name]
        need(PurePosixPath(name).parts[:2]==('images','val') and a['annotation_sha256']==r['annotation_sha256'],
             f'VAL anotasyon kimligi farkli: {name}')
        ap=root/'data/prepared/visdrone_annotations/val'/(PurePosixPath(name).stem+'.txt')
        hp=safe(root/'experiments'/HY,a['path'])
        yp=safe(root/'experiments'/P2,b['path'])
        paths.append((r,g,ap,hp,a['sha256'],yp,b['sha256']))
    missing=Counter()
    sample=[]
    for _,_,ann,hp,_,yp,_ in paths:
        for name,p in [('annotations',ann),('hycado_v1',hp),('yolo1280',yp)]:
            if not p.is_file():
                missing[name]+=1
                if len(sample)<8: sample.append(str(p))
    if missing:
        raise FileNotFoundError(f'Eksik kaynaklar: {dict(missing)}; ornek yollar: {sample}')
    return paths,s_old,s_p2


def sizes(gt):
    import numpy as np
    w,h=gt[:,2:4].T
    return np.where((w<=0)|(h<=0),0,1+np.searchsorted([256,1024,9216],w*h,side='right'))


def counts(flags):
    return tuple(int((flags==v).sum()) for v in (1,0,-1))


def analyze(raw, rec, y, h):
    import numpy as np
    from dev_metrics import ignore_integral, outside_ignore, prepare_groundtruth, xyxy_to_det
    from detailed_matching import detailed_matches
    integral=ignore_integral(raw,rec['width'],rec['height'])
    gt=prepare_groundtruth(raw,integral)
    ids=np.flatnonzero((gt[:,4]==0)&(gt[:,5]>=1)&(gt[:,5]<=10))
    classes=sizes(gt)
    boxes=[outside_ignore(xyxy_to_det(doc),integral)[:500] for doc in (y,h)]
    del integral
    out={}
    for iou in IOU:
        flags=[]; matched=[]
        for det in boxes:
            flags_i, matched_i=detailed_matches(det,gt,iou)
            flags.append(counts(flags_i))
            matched.append(set(map(int,matched_i[flags_i==1])))
        x,z=matched
        need(x.issubset(ids) and z.issubset(ids) and (len(x),len(z))==(flags[0][0],flags[1][0]), 'Gecersiz eslesme')
        by_size=[]
        for j in range(len(AREAS)):
            subset=set(map(int,ids[classes[ids]==j]))
            by_size.append([len(subset),len(subset&x),len(subset&z),len(subset&(z-x)),len(subset&(x-z))])
        out[str(iou)]={'by_size':by_size,'counts':flags}
    return len(ids),out


def rounded_div(num,den):
    return float(100*num/den) if den else None


def contrast(rows, draw_weights, cluster_count, mask=None):
    import numpy as np
    a=np.asarray(rows,dtype=np.int64)
    totals=a.sum(axis=0)
    n,y,h,gained,lost=map(int,totals)
    need(h-y==gained-lost and 0<=y<=n and 0<=h<=n, 'Toplam eslesme tutarsiz')
    if mask is None: mask=np.ones(len(a),dtype=bool)
    clusters_hit=int(np.count_nonzero(cluster_count[mask].sum(axis=0)))
    samples=draw_weights@a
    good=samples[:,0]>0
    draws=100*(samples[good,2]-samples[good,1])/samples[good,0]
    ci=np.percentile(draws,[2.5,97.5]).tolist() if len(draws) else None
    return dict(normal_gt=n,yolo1280_matched=y,hycado_v1_matched=h,
                hycado_only_gt=gained,yolo1280_only_gt=lost,
                yolo1280_recall_pct=rounded_div(y,n),hycado_v1_recall_pct=rounded_div(h,n),
                recall_delta_pp=rounded_div(h-y,n),recall_delta_ci95_pp=ci,
                proxy_clusters=clusters_hit,bootstrap_valid_draws=len(draws))


def summaries(parts, group_ids, expected):
    import numpy as np
    n=np.array([x[0] for x in parts]); ids=np.asarray(group_ids)
    n_groups=int(ids.max()+1)
    rng=np.random.default_rng(DRAW_SEED)
    group_draw=rng.multinomial(n_groups,np.full(n_groups,1/n_groups),size=DRAWS)
    weights=group_draw[:,ids]
    membership=np.eye(n_groups,dtype=np.int8)[ids]
    all_size=[]; all_density=[]; totals={}
    for iou in map(str,IOU):
        area=np.asarray([x[1][iou]['by_size'] for x in parts],dtype=np.int64)
        det=np.asarray([x[1][iou]['counts'] for x in parts],dtype=np.int64)
        need(np.array_equal(n,area[:,:,0].sum(axis=1)), 'Boyut gruplari tum GT kutularini kapsamiyor')
        check=det.sum(axis=0)
        for variant,c in zip(('yolo1280','hycado_v1'),check):
            need(dict(zip(('TP','FP','ignored_detections'),map(int,c)))==expected[variant][iou],
                 f'Dondurulmus toplam TP/FP eslesmedi: {variant}, IoU {iou}')
        totals[iou]={k:dict(zip(('TP','FP','ignored_detections'),map(int,c)))
                     for k,c in zip(('yolo1280','hycado_v1'),check)}
        for j,label in enumerate(AREAS):
            b=area[:,j,:]
            all_size.append(dict(iou=iou,area_px2=label,images_with_gt=int((b[:,0]>0).sum()),
                                 **contrast(b,weights,membership,b[:,0]>0)))
        for label,mask in zip(DENSITY,(n==0,(n>=1)&(n<=30),(n>=31)&(n<=100),n>=101)):
            b=area.sum(axis=1)*mask[:,None]
            y,h=det[mask].sum(axis=0)
            all_density.append(dict(iou=iou,normal_gt_per_image=label,images=int(mask.sum()),
                **contrast(b,weights,membership,mask),
                yolo1280_fp=int(y[1]),hycado_v1_fp=int(h[1]),
                yolo1280_precision_pct=rounded_div(y[0],y[0]+y[1]),
                hycado_v1_precision_pct=rounded_div(h[0],h[0]+h[1])))
    return {'size_rows':all_size,'density_rows':all_density,'verified_detection_totals':totals}


def run(root):
    from dev_metrics import raw_annotation
    evidence={n:json.loads(checked_bytes(HERE/'evidence'/n,h)) for n,h in SHAS.items()}
    paths,s_old,s_p2=preflight(root,evidence)
    parts=[];groups=[]
    for i,(rec,g,ap,hp,hs,yp,ys) in enumerate(paths,1):
        raw=raw_annotation(checked_bytes(ap,rec['annotation_sha256']).decode('utf-8-sig'))
        h=json.loads(checked_bytes(hp,hs)); y=json.loads(checked_bytes(yp,ys))
        assert_payload(h,rec,s_old);assert_payload(y,rec,s_p2)
        need(y['method']=='yolo1280' and len(y['detections'])<=1000 and len(h['hybrid_a025'])<=1000,
             f'Tahmin yontemi veya kutu siniri uyusmuyor: {rec["image"]}')
        parts.append(analyze(raw,rec,y['detections'],h['hybrid_a025']));groups.append(g)
        if i==1 or i%25==0 or i==len(paths): print(f'CPU boyut/yogunluk: {i}/{len(paths)}',flush=True)
    expected={'yolo1280':evidence['official_val_metrics.json']['methods']['yolo1280']['counts_at_fixed_max500'],
              'hycado_v1':evidence['original_metrics.json']['variants']['hybrid_a025']['counts_at_fixed_max500']}
    return dict(status='COMPLETE',images=len(paths),cpu_only=True,trained=False,inference=False,
                source_sha256=SHAS,bootstrap_draws=DRAWS,bootstrap_seed=DRAW_SEED,
                definitions={
                  'scope':'exploratory on previously examined VisDrone VAL, fixed trained weights; not AP-small',
                  'size':'original GT width times height in pixels; full-image matching first',
                  'density':'normal target GT count per image, not spatial density',
                  'matching':'unchanged class-aware full-image reference matching at IoU 0.5 and 0.75; global max500 after ignore filtering',
                  'precision':'pooled TP/(TP+FP) at the fixed output limit for images in the count stratum',
                  'interval':'paired marginal percentile intervals for recall differences using 75 filename/hash proxy clusters, no adjustment or training-seed uncertainty'},
                **summaries(parts,groups,expected))


def bundle(dest,result):
    from io import StringIO
    tmp=dest.with_suffix('.partial')
    with zipfile.ZipFile(tmp,'w',zipfile.ZIP_DEFLATED) as z:
        z.writestr('result.json',json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
        for key in ('size_rows','density_rows'):
            if key not in result: continue
            rows=result[key]; buf=StringIO(newline='')
            writer=csv.DictWriter(buf,fieldnames=list(rows[0]))
            writer.writeheader();writer.writerows(rows)
            z.writestr(key+'.csv',buf.getvalue().encode('utf-8-sig'))
    os.replace(tmp,dest)


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--project',type=Path,default=DEFAULT)
    args=parser.parse_args()
    try:
        result=run(args.project.resolve())
    except (Exception, KeyboardInterrupt) as exc:
        result=dict(status='ERROR',error=str(exc),traceback=traceback.format_exc())
        traceback.print_exc()
    dest=HERE/REPORT
    bundle(dest,result)
    print('SONUC:',result['status'],'\nGONDERILECEK RAPOR:',dest,flush=True)
    raise SystemExit(0 if result['status']=='COMPLETE' else 1)
