# HyCADO v1 ve YOLO-1280 — eşit yanlış alarm analizi

1. ZIP'i ayıklayın. Proje klasörüne kopyalamayın.
2. **17_VAL_ESIT_YANLIS_ALARM.cmd** dosyasını çalıştırın. Varsayılan proje yolu: `D:\HyCADO_Temiz_Baslangic`. Yol farklıysa CMD'ye ilk argüman olarak tam proje yolunu verebilirsiniz.
3. Ayıkladığınız klasörde oluşan **17_val_esit_yanlis_alarm_rapor.zip** dosyasını gönderin. Proje Python'u bulunamaz ve rapor oluşmazsa ekrandaki hatayı paylaşın.

CPU analizi kayıtlı 548 VAL tahminini ve anotasyonlarını yerinde okur. Eğitim, GPU çıkarımı, paket kurulumu veya indirme yoktur. Kaynak dosyalar değişmez. Hash ve eşleştirme toplamları dondurulmuş raporlarla uyuşmazsa işlem durur.

## Ölçüm

- Ana karşılaştırma: **IoU 0,50; görüntü başına ortalama en çok 2 yanlış pozitif**, hem 548 görüntünün tamamında hem de **1–30 normal GT nesnesi** içeren görüntülerde.
- Duyarlılık noktaları: görüntü başına 0,5 / 1 / 2 / 5 / 10 yanlış pozitif ve IoU 0,50 / 0,75. Her yöntem için gerçekleşen yanlış pozitif ortalaması ve recall raporlanır.
- Önceki sınıf duyarlı eşleştirme ve ignore işleminden sonraki görüntü başına en çok 500 tahmin sınırı korunur. Eşit puanlar birlikte alınır; her yöntem için bütçeyi aşmayan en geniş puan dilimi seçilir. Gerçekleşen ortalamalar puan eşitlikleri ve ayrık sayımlar nedeniyle tam aynı olmayabilir; interpolasyon yapılmaz. Arşivin desteklemediği bütçede karşılaştırma raporlanmaz.
- 2.000 eşli grup bootstrap tekrarında her iki yöntem için aynı dosya adı/hash kümeleri örneklenir ve bütçe noktaları tekrar hesaplanır. Bunlar daha önce incelenmiş VAL üzerindeki keşifsel, düzeltmesiz aralıklardır. Rapor dağıtım eşiği veya bağımsız test sonucu vermez.
