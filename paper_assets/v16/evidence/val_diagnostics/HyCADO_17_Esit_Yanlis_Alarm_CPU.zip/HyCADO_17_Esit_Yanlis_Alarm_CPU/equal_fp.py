"""Compare frozen detections at matched FP/image budgets. CPU only."""
import argparse
import csv
from io import StringIO
import json
import os
from pathlib import Path
import traceback
import zipfile
import numpy as np

from analyze import (HERE, DEFAULT, SHAS, assert_payload, checked_bytes,
                     counts, need, preflight)
from detailed_matching import detailed_matches
from dev_metrics import ignore_integral, outside_ignore, prepare_groundtruth, raw_annotation, xyxy_to_det

REPORT = '17_val_esit_yanlis_alarm_rapor.zip'
IOUS = (.5, .75)
# Integer arithmetic makes the at-most-budget rule exact, even at 0.5 FP/image.
BUDGET_TWICE = np.array([1, 2, 4, 10, 20], dtype=np.int64)
METHODS = ('yolo1280','hycado_v1')
DRAWS, SEED = 2000, 20261110


def score_events(det,gt,iou):
    flags,_=detailed_matches(det,gt,iou)
    need(np.isfinite(det[:,4]).all() and np.all(np.diff(det[:,4])<=0),
         'Dondurulmus skorlar azalan sirada veya sonlu degil')
    valid=flags>=0
    return det[valid,4], flags[valid], counts(flags)


def read_pair(rec, ann, hp, hs, yp, ys, old_sig, p2_sig):
    h=json.loads(checked_bytes(hp,hs)); y=json.loads(checked_bytes(yp,ys))
    assert_payload(h,rec,old_sig); assert_payload(y,rec,p2_sig)
    need(y['method']=='yolo1280' and len(y['detections'])<=1000 and len(h['hybrid_a025'])<=1000,
         f'Tahmin yontemi/kutu siniri farkli: {rec["image"]}')
    raw=raw_annotation(checked_bytes(ann,rec['annotation_sha256']).decode('utf-8-sig'))
    integ=ignore_integral(raw,rec['width'],rec['height'])
    gt=prepare_groundtruth(raw,integ)
    dets=[outside_ignore(xyxy_to_det(rows),integ)[:500] for rows in (y['detections'],h['hybrid_a025'])]
    ng=int(np.count_nonzero((gt[:,4]==0)&(gt[:,5]>=1)&(gt[:,5]<=10)))
    return ng, {str(t):[score_events(d,gt,t) for d in dets] for t in IOUS}


def rank_arrays(events, group_ids, n_groups):
    """Rank by exact floating score; rank 0 accepts no detections."""
    lengths=[len(e[0]) for e in events]
    score=np.concatenate([e[0] for e in events])
    flag=np.concatenate([e[1] for e in events])
    groups=np.repeat(group_ids,lengths)
    unique,inv=np.unique(score,return_inverse=True)
    rank=len(unique)-inv
    tp=[];fp=[]
    for i in range(n_groups):
        sel=groups==i
        tp.append(np.sort(rank[sel&(flag==1)]))
        fp.append(np.sort(rank[sel&(flag==0)]))
    return unique[::-1],tp,fp


def weighted_counts(group_lists, ranks, w):
    # ranks is [bootstrap draws, budgets], w is [draws, cluster].
    result=np.zeros(ranks.shape,dtype=np.int64)
    for g,sorted_ranks in enumerate(group_lists):
        if len(sorted_ranks):
            result += w[:,g,None]*np.searchsorted(sorted_ranks,ranks,side='right')
    return result


def operate(scores,tp,fp,w,images,gt):
    """Largest whole tie block under budget, with fresh threshold in each draw."""
    lo=np.zeros((len(w),len(BUDGET_TWICE)),dtype=np.int64)
    hi=np.full(lo.shape,len(scores)+1,dtype=np.int64)
    cap=images[:,None]*BUDGET_TWICE
    while np.any(hi-lo>1):
        mid=(hi+lo)//2
        go=2*weighted_counts(fp,mid,w)<=cap
        active=hi-lo>1
        lo=np.where(active&go,mid,lo)
        hi=np.where(active&~go,mid,hi)
    a=weighted_counts(tp,lo,w); b=weighted_counts(fp,lo,w)
    available=w@np.array([len(q) for q in fp],dtype=np.int64)
    ok=(images[:,None]>0)&(gt[:,None]>0)&(2*available[:,None]>=cap)
    need(np.all(2*b<=cap) and np.all(a<=gt[:,None]),'Isletim noktasi sayimlari tutarsiz')
    recall=np.divide(100*a,gt[:,None],out=np.zeros_like(a,dtype=float),where=gt[:,None]>0)
    return lo,a,b,ok,recall


def summarize(parts, group_ids):
    """Primary: IoU=.50, 2 FP/image, both the full and the 1–30-GT subset."""
    group_ids=np.asarray(group_ids,dtype=np.int64)
    ng=np.array([p[0] for p in parts],dtype=np.int64)
    n_groups=int(group_ids.max())+1
    rng=np.random.default_rng(SEED)
    # Same full-set cluster resamples for both methods and both strata.
    w=np.vstack((np.ones(n_groups,dtype=np.int64),
                 rng.multinomial(n_groups,np.full(n_groups,1/n_groups),size=DRAWS)))
    rows=[]
    for stratum,mask in [('all',np.ones(len(parts),dtype=bool)),('1-30_GT',(ng>=1)&(ng<=30))]:
        members=np.flatnonzero(mask)
        if not len(members): continue
        g=group_ids[members]
        images=w@np.bincount(g,minlength=n_groups)
        gt=w@np.bincount(g,weights=ng[members],minlength=n_groups).astype(np.int64)
        for t in map(str,IOUS):
            curves=[]
            for m in range(2):
                scores,tp,fp=rank_arrays([parts[i][1][t][m] for i in members],g,n_groups)
                curves.append((scores,operate(scores,tp,fp,w,images,gt)))
            for j,b in enumerate(BUDGET_TWICE):
                values=[]
                for scores,(r,tp,fp,ok,recall) in curves:
                    ix=int(r[0,j]); a=int(tp[0,j]); c=int(fp[0,j])
                    values.append(dict(score_threshold=float(scores[ix-1]) if ix else None,
                                       tp=a,fp=c,fp_per_image=c/int(images[0]),
                                       recall_pct=float(recall[0,j]),supports_budget=bool(ok[0,j])))
                oy=curves[0][1]; oh=curves[1][1]
                support=bool(oy[3][0,j]&oh[3][0,j])
                valid=oy[3][1:,j]&oh[3][1:,j]
                delta=oh[4][1:,j]-oy[4][1:,j]
                row=dict(stratum=stratum,iou=float(t),fp_per_image_budget=float(b/2),
                         primary=bool(t=='0.5' and b==4),images=int(images[0]),normal_gt=int(gt[0]),
                         joint_budget_support=support,bootstrap_valid_draws=int(valid.sum()),
                         recall_delta_pp=values[1]['recall_pct']-values[0]['recall_pct'] if support else None,
                         recall_delta_ci95_pp=np.percentile(delta[valid],[2.5,97.5]).tolist()
                         if support and valid.sum()>=int(.95*DRAWS) else None)
                for method,details in zip(METHODS,values):
                    row.update({f'{method}_{k}':v for k,v in details.items()})
                rows.append(row)
    return rows


def run(root):
    evidence={n:json.loads(checked_bytes(HERE/'evidence'/n,h)) for n,h in SHAS.items()}
    paths,old_sig,p2_sig=preflight(root,evidence)
    parts=[];groups=[]
    for i,(rec,g,ann,hp,hs,yp,ys) in enumerate(paths,1):
        parts.append(read_pair(rec,ann,hp,hs,yp,ys,old_sig,p2_sig)); groups.append(g)
        if i==1 or i%25==0 or i==len(paths):
            print(f'CPU eslesme: {i}/{len(paths)}',flush=True)
    expected=[evidence['official_val_metrics.json']['methods']['yolo1280']['counts_at_fixed_max500'],
              evidence['original_metrics.json']['variants']['hybrid_a025']['counts_at_fixed_max500']]
    totals={}
    for t in map(str,IOUS):
        totals[t]={}
        for m,method in enumerate(METHODS):
            actual=dict(zip(('TP','FP','ignored_detections'),
                            map(int,np.sum([p[1][t][m][2] for p in parts],axis=0))))
            need(actual==expected[m][t],f'Arsiv TP/FP toplamiyla fark: {method}, IoU {t}')
            totals[t][method]=actual
    print('Esli grup bootstrap hesaplaniyor...',flush=True)
    return dict(status='COMPLETE',images=len(parts),gpu=False,training=False,inference=False,
                bootstrap_draws=DRAWS,bootstrap_seed=SEED,verified_detection_totals=totals,
                scope='Previously examined official VAL; exploratory, no selected deployment threshold.',
                matching='Same per-image, class-aware reference matching, global max500 after ignore filtering.',
                rule='Largest complete score-tie block with pooled FP / images at or below target, separately per method and stratum; no interpolation.',
                uncertainty='Paired filename/hash cluster percentile interval, curve re-evaluated in each draw; marginal, no multiplicity correction.',
                rows=summarize(parts,groups))


def save(result):
    path=HERE/REPORT
    tmp=path.with_suffix('.partial')
    with zipfile.ZipFile(tmp,'w',zipfile.ZIP_DEFLATED) as z:
        z.writestr('result.json',json.dumps(result,indent=2,ensure_ascii=False,allow_nan=False)+'\n')
        if result.get('rows'):
            buf=StringIO(newline='')
            writer=csv.DictWriter(buf,fieldnames=list(result['rows'][0]))
            writer.writeheader();writer.writerows(result['rows'])
            z.writestr('matched_fp_operating_points.csv',buf.getvalue().encode('utf-8-sig'))
    os.replace(tmp,path)
    return path


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--project',type=Path,default=DEFAULT)
    args=parser.parse_args()
    try:
        result=run(args.project.resolve())
    except (Exception,KeyboardInterrupt) as exc:
        traceback.print_exc()
        result=dict(status='ERROR',error=str(exc),traceback=traceback.format_exc())
    path=save(result)
    print('SONUC:',result['status'],'\nGONDERILECEK RAPOR:',path,flush=True)
    raise SystemExit(0 if result['status']=='COMPLETE' else 1)
